# Implementation Plan – AI‑Agentic Game Architecture

## 1. Architecture of All 6 Agents

| Agent | Directive File | Core Responsibility |
|-------|----------------|---------------------|
| **Prompt Evaluator** | `directives/prompt_evaluator.md` | Scores player‑written heist prompts on clarity, completeness, adaptability, crew utilization, creativity. |
| **Heist Simulator** | `directives/heist_simulator.md` | Executes the heist narrative phase‑by‑phase using the prompt score as a bias. |
| **Crisis Generator** | `directives/crisis_generator.md` | Dynamically injects complications (guards, civilians, technical failures, etc.) based on current alarm level and player history. |
| **Police Counter Agent** | `directives/police_counter_agent.md` | Observes player patterns, infers a dominant tactic, and deploys adaptive counter‑tactics. |
| **Difficulty Calibrator** | `directives/difficulty_calibrator.md` | Consumes five live signals (prompt trend, success rate, alarm level, crisis speed, session length) to keep win‑rate in the 55‑65 % target zone. |
| **Performance Profiler** | `directives/performance_profiler.md` | Summarises per‑mission metrics, computes archetype/dominant‑tactic, and feeds results to the Police Counter and Difficulty Calibrator. |

## 2. How They Connect Together

The **Master Orchestrator** (Agent 7) is the only component that directly calls the others. The orchestration flow for a single mission is:

1. **Initialize** – Master reads `performance_profiler` output, calls **Narrative Director** (outside scope) and **Difficulty Calibrator** to obtain mission parameters.
2. **Briefing** – Master presents the narrative to the player (frontend).
3. **Prompt Evaluation** – When the player submits a prompt, Master invokes **Prompt Evaluator**.
4. **Heist Loop** – Master walks through the four simulation phases, calling **Heist Simulator** for each.
   * After each phase it checks the alarm level. If the alarm exceeds a threshold, it invokes **Police Counter Agent** to modify the state.
   * It also queries **Crisis Generator** (if the phase qualifies) and surfaces the crisis to the player.
5. **Mission End** – When all phases finish, Master calls **Performance Profiler** to log the final metrics.
6. **Difficulty Adjustment** – Master hands the new metrics to **Difficulty Calibrator**, which may tweak future mission parameters.

All inter‑agent communication is performed via JSON payloads – each agent receives a well‑defined input object and returns a JSON output with a mandatory `trace` field describing the reasoning chain.

## 3. Data Flow Between Agents

```
Player Prompt → Prompt Evaluator → score JSON
└─► Master Orchestrator (stores in state.prompt_score)
   └─► Heist Simulator (receives score, mission_context, crew_state)
        ├─► Phase 1 output → Master updates state.alarm_level
        │   ├─► if alarm >= X → Police Counter Agent (counter JSON) → Master updates state.police_counter
        │   └─► if crisis condition → Crisis Generator (crisis JSON) → Master surfaces to player
        └─► repeat for Phases 2‑4

At mission end:
   Master → Performance Profiler (state & outcomes) → profiler JSON
   └─► Difficulty Calibrator (signals) → calibrator JSON
   └─► (optional) Narrative Director for next mission
```

All JSON objects are persisted to `traces/` with a filename matching the originating agent (e.g., `trace_evaluator_output.json`).

## 4. Edge Cases Handled

| Edge Case | Handling Strategy |
|-----------|-------------------|
| Empty or one‑word prompt | Prompt Evaluator forces a **Suicidal** grade, sets `survival_modifier` = ‑0.4, and the Master aborts the mission early. |
| Missing directive file | Each agent falls back to an embedded default system prompt and logs a warning to its trace file. |
| Malformed JSON from a sub‑agent | Master validates JSON schema; on failure it re‑uses the last known good state and records an error in `trace_master_output.json`. |
| Alarm level spikes to 5 | Police Counter Agent is forced to deploy a **Full Lockdown** counter, and the Heist Simulator automatically ends the mission with a “blown” outcome. |
| Crisis generation produces an unsolvable scenario | Crisis Generator performs a feasibility check; if unsolvable it re‑generates until a solvable crisis or gives up after three attempts, logging a `fallback` flag. |
| Difficulty calibrator wants to reduce difficulty two missions in a row | Calibrator respects the rule “never reduce difficulty two missions consecutively without player earning it” – it records a `deferred_adjustment` flag and only applies the reduction after the next successful win. |
| Performance profiler receives corrupted metric | Profiler sanitises inputs (e.g., clamps numeric ranges) and adds a `sanitization` note to its trace. |

## 5. Assumptions Made

1. **Deterministic JSON contracts** – every agent adheres to the schema defined in the SOP markdown; the orchestrator trusts the schema after a single validation pass.
2. **All agents run locally** – no external micro‑services; the only external call is the Gemini API inside `score_prompt.py`.
3. **File system is trustworthy** – trace files are written under `traces/` and never deleted during a session.
4. **Player input is UTF‑8 plain text** – no special characters requiring additional escaping beyond JSON encoding.
5. **Resource limits are generous** – the orchestration loop executes within a single process; no background workers are needed.
6. **Version stability** – the code assumes the same version of the directive markdown files throughout a run; if a file changes, the orchestrator reloads it on the next mission.

---
*Document generated by the AI planning sub‑agent as part of the Antigravity project.*
